---
name: context-compressor
description: Compress long text, logs, prompts, research notes, or handoff context while preserving decisions, constraints, evidence, exact literals, and unresolved work. Use when the user asks to shorten context, reduce tokens, prepare a compact handoff, or extract the information needed for a later task; do not silently rewrite source material or active session files.
---

# Context Compressor

Create a smaller representation that another reader or agent can act on without reopening the source.

## Workflow

1. Identify the target use, audience, and any requested length or compression ratio.
2. Separate immutable payload from compressible prose.
3. Remove repetition, ceremony, superseded exploration, and low-value tool output.
4. Merge equivalent facts and retain provenance when competing claims remain.
5. Check the result against the preservation rules before delivery.

## Preserve Exactly

- User intent, acceptance criteria, permissions, prohibitions, and scope boundaries.
- Negations, exceptions, uncertainty, failed attempts, blockers, and unresolved questions.
- Names, dates, numbers, units, identifiers, URLs, file paths, commands, code, configuration keys, and decisive error text.
- Current state versus planned, attempted, verified, and accepted state.
- Source attribution when it affects trust or later verification.

Never invent missing links or convert an estimate into a confirmed fact. Mark conflicts and uncertainty instead of smoothing them away.

## Output Shape

Match the user's requested format. For a reusable handoff, prefer these compact fields when relevant:

- Objective
- Current state
- Decisions and constraints
- Evidence and exact literals
- Failed attempts or retired options
- Open questions and next action

Do not force this structure on ordinary summaries.

## Source Safety

Compression is non-destructive by default. Return compressed text separately and leave source files, prompts, and conversation history unchanged unless the user explicitly requests an edit.

If the user asks to install or integrate the original Python package, read [references/python-package.md](references/python-package.md) first.
