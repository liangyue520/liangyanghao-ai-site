# Original Python Package

Read this reference only when the user asks to install, run, audit, or integrate the original `context-compressor` Python package.

## Local Source

- Archive: `E:\公司skils\context-compressor-main.zip`
- Package name: `context-compressor`
- Version declared in the archive: `1.0.3`
- Python requirement: `>=3.8`
- License declared in the archive: MIT

The archive is a Python library, not a native Codex Skill. Its default dependency set includes large ML and data packages such as PyTorch, Transformers, sentence-transformers, datasets, spaCy, LangChain, FastAPI, plotting libraries, and provider SDKs.

## Integration Rules

- Do not install the package merely because this Skill was invoked.
- Before installation, report the target Python environment and expected dependency footprint.
- Prefer a dedicated virtual environment so package versions do not alter unrelated projects.
- Inspect the current package metadata and source before executing it.
- Run a small local verification after installation and report actual behavior.
- Treat performance and token-reduction percentages in project documentation as unverified claims until reproduced on the user's data.

The archive exposes a `context-compressor` command and a Python API centered on `ContextCompressor`. Use the package's current help and source as the authority for exact runtime options.
