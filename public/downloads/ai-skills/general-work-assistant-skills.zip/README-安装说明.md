# 通用工作辅助 Skills

本压缩包包含 5 个 Codex Skill。每个目录是一个独立 Skill，请保留其目录结构和 SKILL.md。

使用时按需把对应 Skill 文件夹放入 Codex 的 Skills 目录。若 Skill 目录内有 references、scripts 或 examples，请与 SKILL.md 一起保留。

- caveman
- context-compressor
- gobstopper
- multi-agent-dev-sop
- three-minute-stop