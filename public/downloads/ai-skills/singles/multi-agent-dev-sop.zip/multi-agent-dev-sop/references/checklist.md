# Checklists

## New Project Startup

- [ ] Project goal is stated in one sentence.
- [ ] User/stakeholder and acceptance owner are known.
- [ ] Current version target and delivery date are known.
- [ ] Editable workspace and read-only references are separated.
- [ ] Source materials have versions or source locations.
- [ ] Existing code, deploy artifacts, docs, and data samples are inventoried.
- [ ] Core business chain is identified.
- [ ] Design baseline tasks are defined.
- [ ] Common contracts are identified or scheduled.
- [ ] File ownership and public modules are defined.
- [ ] Database, ports, accounts, credentials policy, and runtime resources are known.
- [ ] Mock/sample/stub/unconnected capabilities are labelled.
- [ ] Initial blockers have owners and unblock conditions.
- [ ] Acceptance evidence format is agreed.

## Onsite or Customer Demo

- [ ] Startup script exists and was run on the intended machine.
- [ ] Browser URL, backend URL, logs, stop method, and recovery method are documented.
- [ ] Port availability was checked.
- [ ] Database and Redis/cache availability were checked.
- [ ] Login was verified with the intended account.
- [ ] At least one core business chain was verified with a known sample.
- [ ] Unconnected services are listed and can be explained.
- [ ] Demonstration route has a fallback if map/3D/external services fail.
- [ ] Leader-facing explanation distinguishes current verified scope from target architecture.

## Design Review

- [ ] Technical architecture aligns with data flow.
- [ ] Deployment diagram aligns with verified environment.
- [ ] Business flow aligns with roles and permissions.
- [ ] Data flow preserves authoritative write path.
- [ ] External services have health checks or are marked unconnected.
- [ ] Version labels do not overstate evidence.

