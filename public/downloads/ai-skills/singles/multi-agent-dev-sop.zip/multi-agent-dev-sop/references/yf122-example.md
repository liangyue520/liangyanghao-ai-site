# YF122 / 122 Example

Use this reference only for the user's 122/YF122 project or as a concrete example when the user asks how the SOP applies.

## Project Interpretation

122 is a satellite target data reorganization, display, and graph-analysis system.

Main chain:

```text
manual / Excel / document extraction / crawler / graph suggestion
  -> reorganization batch
  -> difference and review
  -> authoritative snapshot/core/detail
  -> display, statistics, Cesium situation, graph index
```

## Key Boundary

Reorganization is the authoritative write path. Display, statistics, Cesium, and graph modules consume reviewed authoritative data. Graph suggestions must return to review; they must not bypass review and write authoritative data directly.

## Current Verified Local Scope

The 122 local setup used:

- Frontend: `http://127.0.0.1:3100`.
- Backend: `http://127.0.0.1:18080`.
- Local database: MySQL `satdb`.
- Redis via local/Docker environment.
- One-click launch script in `%USERPROFILE%\LY\YF122\协作管理\部署\`.

Verified or recorded as locally working:

- One-click restart and basic frontend/backend/proxy checks.
- Login, satellite list, grouping, display search smoke checks.
- Earlier sample flow for import, review, snapshot update, and display search.

Not to claim as completed unless separately verified:

- Neo4j graph service.
- NLP document extraction model service.
- External OSS bucket.
- Crawler push as real import capability.
- GBase production operation.
- TLE professional precision.
- Cesium page-by-page manual acceptance.

## Useful Explanation for a C++ Developer

Explain the system as:

```text
Browser UI
  -> frontend Vue application
  -> HTTP API
  -> Java Spring Boot service
  -> MySQL/GBase authoritative state
  -> display/statistics/Cesium/graph consumers
```

Explain Redis as a fast shared runtime cache, similar in spirit to a process-independent `unordered_map` with expiration, not as the authoritative business database.

Explain `snapshot/core/detail` as the official satellite data area:

- `snapshot`: identity and current snapshot fields.
- `core`: core business/platform fields.
- `detail`: extended details and field source.

Use the analogy:

```text
batch / pending / audit_log = workflow records
snapshot / core / detail = stamped official archive
```

