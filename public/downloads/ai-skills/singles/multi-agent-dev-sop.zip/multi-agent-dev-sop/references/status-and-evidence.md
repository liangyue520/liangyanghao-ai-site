# Status and Evidence Reference

## Status Vocabulary

Use these terms strictly:

| State | Meaning | Evidence |
| --- | --- | --- |
| Planned | Expected work exists but has not started | Task card or roadmap |
| Implemented | Artifact or code exists | File diff, build output, generated document |
| Tested | A defined check ran | Test command, case result, environment |
| Verified | Real workflow worked in stated conditions | Steps, data, version, screenshots/logs/API output |
| Accepted | Stakeholder accepted scope | Acceptance owner, date, version, reservations |
| Blocked | Work cannot continue for scoped reason | Missing input/service/decision and unblock condition |
| Deferred | Not in current version | Target version, owner, reason |

## Bug Triage

Classify by impact:

- P0: system cannot start, login blocked, data corruption risk, or required demo path unusable.
- P1: required business chain fails without acceptable workaround.
- P2: non-blocking feature defect, display issue, partial validation gap.
- P3/backlog: improvement, optimization, next-version work.

Diagnosis order:

1. Confirm version, environment, and data mode.
2. Reproduce minimally.
3. Check browser Network and Console.
4. Check backend logs and interface contract.
5. Check database/cache/files and external service health.
6. Fix the smallest responsible area.
7. Re-run affected checks and update evidence.

## Reporting to Leaders

Organize reports in three layers:

1. Design layer: system architecture, module boundary, data authority, deployment target.
2. Engineering layer: current version scope, task progress, blockers, next phase.
3. Software layer: what can be opened and operated now, what has been verified, what is sample/stub/unconnected.

Use this sentence pattern:

```text
当前版本已完成 [verified scope]，可演示 [operation path]；
[unverified scope] 属于后续接入/验收项；
本轮结论基于 [version/environment/data]。
```

