# Workflow Reference

Use this reference for full multi-agent software project organization.

## Sixteen-Step SOP

1. Clarify goal and success standard.
2. Collect materials and inventory current implementation.
3. Split design-analysis tasks.
4. Run parallel analysis with a unified report format.
5. Perform consistency review and issue grading.
6. Establish the system design baseline.
7. Convert design into development tasks.
8. Cut the version scope and verify critical technical risks.
9. Freeze common contracts and file boundaries.
10. Build the reusable business loop and product shell.
11. Start eligible parallel work batches.
12. Review deliverables and integrate through the coordinator.
13. Run integration and real-operation verification.
14. Triage bugs, apply minimal fixes, and regress.
15. Perform human acceptance and prepare leader-facing report.
16. Close the version and plan the next round.

## Design Baseline Pattern

For design work, split into:

- A1 Technical architecture: frontend, backend, data, extension services, common contracts.
- A2 Hardware/software deployment: local verification, target environment, dependencies, ports, startup, logs.
- A3 Data flow: sources, batch/pending/review, authoritative state, consumers, synchronization.
- A4 Business flow: roles, operations, approvals, read-only users, admin actions.
- A5 Consistency review: conflicts, blocked items, current verified scope, next tasks.

## Task Matrix Fields

Each task should include:

- Task ID and title.
- Responsible role.
- Inputs and baseline version.
- Output artifacts.
- Predecessors and downstream consumers.
- File or module ownership.
- Data/interface dependencies.
- Shared resources such as port, database, account, browser session, or deployment machine.
- Acceptance criteria.
- Self-test or verification method.
- Blockers and decision owner.

## Parallel Judgment

Tasks may run in parallel when all are true:

- They do not need each other's unfinished output.
- They do not edit the same files or shared public contract.
- They do not compete for the same mutable runtime resource.
- Their interface contract is stable or versioned.
- Each has an independent acceptance check.

Make tasks sequential when one produces the design baseline, contract, migration, launch script, shared type, database schema, or acceptance data for another.

## Version Cutting

Prefer a thin verified chain over a large unverified surface:

- V0.1: minimal visible or usable chain, with fixed limitations clearly marked.
- V0.2: broader operations and interaction.
- V0.3: real data or external services.
- V0.4: core business closed loop.
- V0.5: integrated QA, deployment, recovery, permissions.
- V1.0: accepted scope with evidence and handoff.

Do not let the version label imply untested capability.

## File Boundaries

Create one owner for shared files:

- Routes, layout, request utilities, common types, global store.
- Domain entities, mappers, database migrations, public service contracts.
- Deployment scripts, environment files, shared mock data.
- Test fixtures and release documents.

Specialist agents may consume shared files but should not independently modify them unless the coordinator assigns that ownership.

