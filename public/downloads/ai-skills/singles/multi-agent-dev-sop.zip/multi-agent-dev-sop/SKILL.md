---
name: multi-agent-dev-sop
description: Apply a Chinese multi-agent software-development SOP for project planning, task splitting, parallel agent coordination, integration testing, evidence-based acceptance, deployment handoff, and version closure. Use when the user asks to reuse the multi-agent workflow, create project division, architecture/design baselines, development task boards, prompts, acceptance plans, or status/leader-report materials.
metadata:
  short-description: 多智能体协同软件开发SOP
---

# AI 多智能体协同软件开发 SOP

Use this skill when the user wants to organize a software project with a "one coordinator + specialist agents + reviewer/test/documentation" workflow. The usual outcome is a concrete set of project artifacts: role division, task matrix, dependency plan, file boundaries, common contract, version scope, acceptance evidence, and reusable prompts.

The user may be a C++ developer who is not a frontend/backend specialist. Prefer concrete, evidence-led explanations in Chinese. When explaining web/backend concepts, map them to familiar ideas such as UI layer, service layer, persistent state, cache, process, port, input/output, and state transition.

## Core Operating Rule

Keep one total coordinator for the active round. Specialist agents or tasks may work in parallel only after inputs, outputs, dependencies, file ownership, shared resources, and acceptance criteria are clear.

Do not equate "implemented", "tested", "verified", and "accepted". Treat them as separate states:

- Implemented: code or artifact exists.
- Tested: a defined check ran and produced a result.
- Verified: the real target workflow worked under a stated environment and data set.
- Accepted: the named user or stakeholder accepted a specific version and scope.

## Default Workflow

For ordinary project organization requests, follow this order:

1. Identify the project goal, stakeholder, current materials, editable paths, and read-only references.
2. Establish a design baseline before broad development: technical architecture, deployment architecture, data flow, business flow, and consistency review.
3. Convert the baseline into a development task matrix with roles, dependencies, file boundaries, common contracts, tests, and acceptance criteria.
4. Split the version scope into V0.1/V0.2/... or another project-appropriate release path.
5. Start only tasks whose prerequisites are satisfied; leave blocked tasks documented, not silently skipped.
6. Integrate through the coordinator, run meaningful checks, record evidence, classify bugs, and update version artifacts.
7. Prepare user-facing handoff: launch method, verified functions, unverified scope, known issues, rollback or recovery notes, and human acceptance steps.

Read [references/workflow.md](references/workflow.md) when producing a full task plan, role split, architecture baseline, or project board.
Read [references/prompts.md](references/prompts.md) when the user asks for copyable prompts.
Read [references/checklist.md](references/checklist.md) when starting a new project or preparing onsite acceptance.
Read [references/status-and-evidence.md](references/status-and-evidence.md) when reporting progress, handling bugs, writing release notes, or distinguishing verified scope from planned capability.
Read [references/yf122-example.md](references/yf122-example.md) when the request is about the 122/YF122 project or when the user wants an example based on that project.
Read [references/source-sop-v2.md](references/source-sop-v2.md) only when the user asks for the full original SOP text or a detail not covered by the shorter references.

## Role Model

Use roles as responsibilities, not as a requirement to create separate conversations:

- User/business owner: goal, priority, decisions, final acceptance.
- Design coordinator: evidence collection, architecture baseline, consistency review.
- Development coordinator: task matrix, dependencies, contracts, file ownership, integration.
- Specialist agent: bounded implementation or analysis for frontend, backend, data, model, UI, deployment, or documentation.
- Reviewer: independent consistency/code/interface review.
- Test/QA: real operation checks, defect reproduction, regression, acceptance evidence.
- Documentation/release: launch notes, known limits, demo scripts, version closure, rollback notes.

When tool-level subagents or sidebar tasks are available, create them only when the user asks for agent delegation, parallel agent work, or new tasks. Otherwise express the roles in the plan and artifacts.

## Non-Negotiable Boundaries

- Record fixed samples, mock data, stubs, unconnected services, and unverified algorithms as such.
- Do not claim external services are connected without health checks and a sample that proves data reached the service.
- Do not use page visibility, port listening, or a successful startup log as proof that the business workflow is verified.
- Do not let a graph, search, display, report, or demo module bypass the authoritative write-and-review path when the project defines one.
- Bind all evidence to a version, environment, data mode, and operation steps.

## Typical Deliverables

For a new or reorganized project, create or update:

- `00_项目分工总览.md`
- `01_基线冲突与阻塞.md`
- `02_任务卡与文件边界.md`
- `03_执行任务板.md`
- `04_总控接管Prompt.md`
- Architecture/design files for technical architecture, deployment architecture, data flow, business flow, and consistency review.
- Deployment or acceptance records when deployment is in scope.

Adapt names to the project. Use the repository's existing conventions when present.
