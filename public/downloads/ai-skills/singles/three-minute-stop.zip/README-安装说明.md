本压缩包包含 1 个 Codex Skill：three-minute-stop。

保留目录结构和 SKILL.md。使用时按需把对应 Skill 文件夹放入 Codex 的 Skills 目录。若目录内有 references、scripts 或 examples，请与 SKILL.md 一起保留。