---
name: gobstopper
description: Inspect, configure, and safely operate the Gobstopper context-compaction tool for long Codex, Claude Code, and compatible coding-agent sessions. Use when the user names Gobstopper or asks to preview, reduce, recover, or measure saved or live agent context with that tool; do not install a persistent proxy or modify session data without explicit authorization.
---

# Gobstopper

Help the user reduce repeated coding-agent context while keeping the operation inspectable and recoverable.

## Default Workflow

1. Determine whether the `gobstopper` binary is installed and inspect its current `--help` output.
2. Identify the exact client, session, context threshold, and desired outcome.
3. Start with read-only diagnostics or previews.
4. Explain what will be kept, summarized, dropped, copied, or routed before changing anything.
5. For saved sessions, preserve the original and write a separate candidate or fork.
6. Verify the candidate's structure and retained recent output before suggesting resume or replacement.
7. Report the exact source, output, strategy, threshold, verification result, and recovery path.

## Safe Defaults

- Prefer `doctor`, `status`, `plan`, `diff`, `watch --dry-run`, and proxy replay modes before apply or service operations.
- Never overwrite an original transcript or session file in place.
- Never enable a login service, persistent proxy, automatic update, plugin, or provider routing without explicit user authorization.
- Warn that a live proxy can observe prompts, responses, tool output, and authentication-related traffic even when it runs locally.
- Do not send transcript content to an external model or service unless the user explicitly authorizes it.
- Do not treat fewer tokens as success by itself. Check retained constraints, exact errors, recent tool results, and task continuity.
- If command behavior differs from this Skill, stop and use the installed version's help as the authority.

## Installation Boundary

This Skill does not install or start the Gobstopper executable automatically. If the binary is absent or the user requests setup, read [references/operations.md](references/operations.md) before proceeding.
