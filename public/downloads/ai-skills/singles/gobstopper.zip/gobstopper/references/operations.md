# Gobstopper Operations

Read this reference only for installation, command execution, proxy setup, saved-session changes, or recovery.

## Local Source

- Archive: `E:\公司skils\gobstopper-main.zip`
- Implementation: Rust command-line application
- Licenses declared in the archive: Apache-2.0 and MIT

The archive contains source code, not a ready-to-run Codex Skill or a confirmed Windows binary.

## Capability Map

Confirm every command against the installed version's `gobstopper --help` before use.

- `gobstopper doctor`: diagnose local setup.
- `gobstopper proxy status`: show proxy counters and estimated token totals.
- `gobstopper proxy replay <session>`: preview what the proxy would send without calling a provider.
- `gobstopper watch --dry-run`: inspect threshold decisions without preparing copies.
- `gobstopper plan <session>` and `gobstopper diff`: inspect a proposed saved-session cut.
- `gobstopper verify <session>`: run supported structural checks.
- `gobstopper vault` and `gobstopper undo`: inspect or recover archived snapshots when supported.
- `gobstopper proxy run -- <client>`: route one child client session through a temporary local proxy.
- `gobstopper proxy serve` or `proxy install`: start longer-lived proxy behavior; these require explicit authorization.

## Installation and Execution

- Do not execute remote pipe-to-shell or pipe-to-PowerShell installers automatically.
- Prefer a signed or checksum-verified release from the project's authoritative source, or build the reviewed archive from source with a pinned Rust toolchain.
- State the destination and persistence behavior before installation.
- After installation, record the exact version and run read-only diagnostics before proxying a real session.

## Saved Sessions

Resolve the exact source path and hash before any apply operation. Create a new fork or candidate, keep the source byte-for-byte, then verify protected recent output and required constraints. Never equate a successful command exit with semantic continuity.

## Live Proxy

Bind only to loopback unless the user explicitly requests and understands broader exposure. Explain provider routing, authentication forwarding, logs, startup behavior, and removal before enabling a persistent service.
